echo "正在准备安装 SimpleDocker...."

wget
