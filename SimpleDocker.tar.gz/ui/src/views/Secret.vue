<template>
  <div class="secret">
    <h1>安全认证功能暂未完成</h1>
  </div>
</template>
