module.exports = {
  publicPath: './'

}
